// export const apiurl = "http://52.200.251.222:8152/api/v1/";
// export const apiurl = "http://59.92.232.178:8152/api/v1/";
export const apiurl = "http://www.goldenpalmcanteen.in:8152/api/v1/";
export default apiurl;  