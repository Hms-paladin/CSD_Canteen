import { GET_PICKLIST_DATA } from "./constants";
import axios from "axios";
import apiurl from "../utils/baseUrl";
import dateformat from "dateformat";

export const getPrintListData = (startDate, endDate) => async dispatch => {
    try {
        const config = {
            headers: {
                "Content-Type": "application/json"
            }
        }
        const body = {
            date: startDate ? dateformat(startDate, "yyyy-mm-dd") : dateformat(new Date(), "yyyy-mm-dd"),
            date_to: endDate ? dateformat(endDate, "yyyy-mm-dd") : dateformat(new Date(), "yyyy-mm-dd")

            // date:"2021-2-2"
        }
        const url = `${apiurl}getPickListDetailsWeb`;
        const res = await axios.post(url, body, config);
        dispatch({ type: GET_PICKLIST_DATA, payload: res.data.data });
    } catch (err) {
    }
}